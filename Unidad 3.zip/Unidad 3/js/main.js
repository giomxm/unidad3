function load_main() {
    activities_moodle();
    center_intro();
    $('.button-collapse').sideNav({
        closeOnClick: false,
        draggable: true
    });
    submenu_load();
    $('.paginate').hide();
}

function load_functions() {
    activities_moodle();
    center_intro();
    $('.modal').modal({
        outDuration: 1000
        , dismissible: false
    });
    $('.modal.bottom-sheet').unbind().modal({
        outDuration: 1000
        , dismissible: true
    });
    $(window).resize(function () {
        center_intro();
    });
    $('.button-collapse').sideNav({
        closeOnClick: false,
        draggable: true
    });
    submenu_load();
    $('.materialboxed').materialbox();
    $('.collapsible').collapsible();
    $('.tooltipped').tooltip({
        delay: 50
    });
    load_lateral_paginate();
    load_paginate();
    load_paginate_into();
    $('#open_pagination').click(function (event) {
        event.preventDefault();
        $('#pagination a').click(function (event) {
            console.log('Close')
            $('#pagination').modal('close');
        })
    });
    accesibility();
    /* Actividades */
    input_global();
    input_row();
    input_list();
    check_button();
    element_progress();
    element_progress_field();
    fichero();
    radio_truefalse();
    drag_drop();
    drag_drop_inner();
    orden_list();
}

/*
 * Actividades Moodle
*/
function activities_moodle(){
   $.each(activities, function (key, item) {
        $('#' + item.activity).attr('href', (course_platform + item.url + item.moodle));
    });
}
/* */

function submenu_load(){
    $('a.unit-link').unbind().click(function (event) {
        event.preventDefault();
        var open_close = $(this).data('state');
        if (open_close == 'close') {
            $(this).data('state', 'open');
            $(this).find('i').removeClass().addClass('fa fa-caret-down');
            $(this).closest('.unit-reference').find('ul').show();
        } else {
            $(this).data('state', 'close');
            $(this).find('i').removeClass().addClass('fa fa-caret-right');
            $(this).closest('.unit-reference').find('ul').hide();
        }
        $(this).closest('.unit-reference').find('ul > li > a').click(function (event) {
            $(this).closest('.unit-reference').find('a').data('state', 'close');
            $(this).find('i').removeClass().addClass('fa fa-caret-right');
            $(this).closest('.unit-reference').find('ul').hide();
            $('.button-collapse').sideNav('hide');
        });
    });
}

function center_intro() {
    var position = $('.intro').position();
    if ($(window).height() > $('.intro').height()) {
        var top = ($(window).height() - $('.intro').height()) / 2;
    }
    else {
        var top = position.top;
    }
    $('.intro').css('margin-top', top + 'px');
}

function load_paginate() {
    $('.slide-out li > a').click(function (event) {
        event.preventDefault();
        get_paginate($(this).data('unit'));
    });
}

function load_paginate_into() {
    if ($('#content').length) {
        get_paginate($('#content').data('unit'));
        $('#place').text($('#contet').data('place'));
        $('#unit-title').text($('section .row').data('title'));
        console.log('title ' + $('section .row').data('title'))
    }
}

function get_paginate() {
    console.log('pag')
    $.get('content/paginate.html', function (data) {
        $('#pagination > .modal-content').html(data);
        $('#total').text($('#pagination > .modal-content ul li').length);
    });
}

function load_lateral_paginate() {
    var previous, next = '';
    previous = $('#content').data('previous');
    next = $('#content').data('next');
    if (previous) {
        $('#previous').attr('href', previous).show();
    }
    else {
        $('#previous').hide();
    }
    if (next) {
        $('#next').attr('href', next).show();
    }
    else {
        $('#next').hide();
    }
    $('.paginate').css('top', ($(window).height() / 2) + 'px');
    $('#place').text($('#content').data('place'));
    if ($('#content').data('unit')) {
        load_paginate($('#content').data('unit'));
    }
}

function accesibility() {
    var font_size = '';
    $('.accesibility').unbind('click').click(function (event) {
        event.preventDefault();
        switch ($(this).find('i').text()) {
        case 'settings_brightness':
            if (!$('body.brightness').length) {
                $('body').addClass('brightness');
                $('body.brightness').css('background', '#000');
            }
            else {
                $('body').removeClass('brightness');
                $('body').css('background', 'transparent');
            }
            break;
        case 'zoom_out':
            $('html').css('font-size', (parseFloat($('html').css('font-size'), 10) * 0.8));
            break;
        case 'zoom_in':
            $('html').css('font-size', (parseFloat($('html').css('font-size'), 10) * 1.2));
            break;
        }
    });
}
/*
 * Actividades
 */
/* Input Retroalimentación Global */
function input_global() {
    $('.input-global button').click(function (event) {
        event.preventDefault();
        var allComplete = true;
        var thisForm = $(this).closest('.input-global');
        var allCorrect = true;
        thisForm.find('input').removeClass('correct');
        thisForm.find('input').removeClass('incorrect');
        thisForm.find('.retro > div').hide();
        thisForm.find('input').each(function () {
            if ($(this).val() == '') {
                $(this).addClass('incomplete');
                allComplete = false;
            }
        });
        if (allComplete) {
            thisForm.find('input').removeClass('incomplete');
            var allCorrect = true;
            thisForm.find('input').each(function () {
                var thisInput = $(this);
                var responseInput = $(this).data('result').split('|');
                $.each(responseInput, function (index, value) {
                    if (thisInput.val().toLowerCase() == value) {
                        allCorrect = true;
                        thisInput.removeClass('incorrect');
                        thisInput.addClass('correct');
                        return false;
                    }
                    else {
                        allCorrect = false;
                        thisInput.addClass('incorrect');
                    }
                });
            });
            if (allCorrect) {
                thisForm.find('.positive').fadeIn(2000);
            }
            else {
                thisForm.find('.negative').fadeIn(2000);
            }
        }
    });
}
/* Input Retroalimentación por Línea */
function input_row() {
    $('.input-row button').click(function (event) {
        event.preventDefault();
        var allComplete = true;
        var thisForm = $(this).closest('form');
        thisForm.find('input').removeClass('correct');
        thisForm.find('input').removeClass('incorrect');
        thisForm.find('.retro > div').hide();
        thisForm.find('input').each(function () {
            if ($(this).val() == '') {
                $(this).addClass('incomplete');
                allComplete = false;
            }
        });
        if (allComplete) {
            thisForm.find('input').removeClass('incomplete');
            thisForm.find('.row').each(function () {
                var allCorrect = true;
                var thisRow = $(this);
                thisRow.find('input').each(function () {
                    var thisInput = $(this);
                    var responseInput = $(this).data('result').split('|');
                    $.each(responseInput, function (index, value) {
                        if (thisInput.val().toLowerCase() == value) {
                            allCorrect = true;
                            thisInput.removeClass('incorrect');
                            thisInput.addClass('correct');
                            return false;
                        }
                        else {
                            allCorrect = false;
                            thisInput.addClass('incorrect');
                        }
                    });
                });
                if (allCorrect) {
                    thisRow.find('.positive').fadeIn(2000);
                }
                else {
                    thisRow.find('.negative').fadeIn(2000);
                }
            });
        }
    });
}
/* Input Retroalimentación por Línea en Lista */
function input_list() {
    $('.input-list button').click(function (event) {
        event.preventDefault();
        var allComplete = true;
        var thisForm = $(this).closest('form');
        thisForm.find('input').removeClass('correct');
        thisForm.find('input').removeClass('incorrect');
        thisForm.find('.retro > div').hide();
        thisForm.find('input').each(function () {
            if ($(this).val() == '') {
                $(this).addClass('incomplete');
                allComplete = false;
            }
        });
        if (allComplete) {
            thisForm.find('input').removeClass('incomplete');
            thisForm.find('li').each(function () {
                var allCorrect = true;
                var thisRow = $(this);
                thisRow.find('input').each(function () {
                    var thisInput = $(this);
                    var responseInput = $(this).data('result').split('|');
                    $.each(responseInput, function (index, value) {
                        if (thisInput.val().toLowerCase() == value) {
                            allCorrect = true;
                            thisInput.removeClass('incorrect');
                            thisInput.addClass('correct');
                            return false;
                        }
                        else {
                            allCorrect = false;
                            thisInput.addClass('incorrect');
                        }
                    });
                });
                if (allCorrect) {
                    thisRow.find('.positive').fadeIn(2000);
                }
                else {
                    thisRow.find('.negative').fadeIn(2000);
                }
            });
        }
    });
}
/* Selección de Respuesta por Botón */
function check_button() {
    $('.check-button .check-it').click(function (event) {
        event.preventDefault();
        $(this).closest('.check-group').find('.retro > div').hide();
        $(this).closest('.check-group').find('.check-it').removeClass('correct');
        $(this).closest('.check-group').find('.check-it').removeClass('incorrect');
        if ($(this).data('response')) {
            $(this).addClass('correct');
            $(this).closest('.check-group').find('.positive').fadeIn(1000);
        }
        else {
            $(this).addClass('incorrect');
            $(this).closest('.check-group').find('.negative').fadeIn(1000);
        }
    })
}
/* Responde y Avanza */
function element_progress() {
    $('.response-progress .element-progress').hide();
    var thisProgress = 0;
    $('.response-progress .element-progress').eq(thisProgress).show();
    $('.response-progress button').click(function (event) {
        event.preventDefault();
        var allComplete = true;
        var thisForm = $(this).closest('form');
        var thisElement = thisForm.find('.element-progress').eq(thisProgress);
        thisElement.find('input').each(function () {
            if ($(this).val() == '') {
                allComplete = false;
                $(this).addClass('incomplete');
            }
        });
        if (allComplete) {
            var allCorrect = true;
            thisForm.find('input').removeClass('incomplete');
            thisElement.find('input').each(function () {
                var thisInput = $(this);
                var responseInput = thisInput.data('result').split('|');
                $.each(responseInput, function (index, value) {
                    if (thisInput.val().toLowerCase() == value) {
                        allCorrect = true;
                        thisInput.removeClass('incorrect');
                        thisInput.addClass('correct');
                        return false;
                    }
                    else {
                        allCorrect = false;
                        thisInput.addClass('incorrect');
                    }
                });
                if (allCorrect) {
                    thisElement.find('.positive').fadeIn(2000);
                }
                else {
                    thisElement.find('.negative').fadeIn(2000);
                }
            });
            thisProgress++;
            if (thisProgress < thisForm.find('.element-progress').length) {
                thisForm.find('.element-progress').eq(thisProgress).fadeIn(2000);
            }
            else {
                thisForm.find('button').addClass('disabled');
            }
        }
    });
}
/* Responde y Avanza por Campo */
function element_progress_field() {
    $('.response-progress-field .element-progress').hide();
    var thisProgress = 0;
    $('.response-progress-field .element-progress').eq(thisProgress).show();
    $('.response-progress-field button').click(function (event) {
        event.preventDefault();
        var allComplete = true;
        var thisForm = $(this).closest('form');
        var thisElement = thisForm.find('.element-progress').eq(thisProgress);
        thisElement.find('input').each(function () {
            if ($(this).val() == '') {
                allComplete = false;
                $(this).addClass('incomplete');
            }
        });
        if (allComplete) {
            var allCorrect = true;
            thisForm.find('input').removeClass('incomplete');
            thisElement.find('.input-field').each(function () {
                var thisInputField = $(this);
                $(this).find('input').each(function () {
                    var thisInput = $(this);
                    var responseInput = thisInput.data('result').split('|');
                    $.each(responseInput, function (index, value) {
                        if (thisInput.val().toLowerCase() == value) {
                            allCorrect = true;
                            thisInput.removeClass('incorrect');
                            thisInput.addClass('correct');
                            return false;
                        }
                        else {
                            allCorrect = false;
                            thisInput.addClass('incorrect');
                        }
                    });
                    if (allCorrect) {
                        thisInputField.find('.positive').fadeIn(2000);
                    }
                    else {
                        thisInputField.find('.negative').fadeIn(2000);
                    }
                });
            });
            thisProgress++;
            if (thisProgress < thisForm.find('.element-progress').length) {
                thisForm.find('.element-progress').eq(thisProgress).fadeIn(2000);
            }
            else {
                thisForm.find('button').addClass('disabled');
            }
        }
    });
}
/* Fichero */
function fichero() {
    var thisElement = 0;
    $('.tabs-fichero').each(function(){
        $(this).find('.content-tabs').hide();
        $(this).find('.content-tabs').eq(thisElement).show();
    });
    $('.tabs-fichero .tablist li a').click(function (event) {
        event.preventDefault();
        $(this).closest('.tabs-fichero').find('.content-tabs').hide();
        thisElement = $(this).closest('li').index();
        $(this).closest('.tabs-fichero').find('.content-tabs').eq(thisElement).fadeIn(3000);
    });
}
/* Radio Button */
function radio_truefalse() {
    $('.radio-truefalse label').click(function (event) {
        $(this).closest('.input-field').find('.retro > div').hide();
        $(this).closest('.input-field').find('p').removeClass('correct');
        $(this).closest('.input-field').find('p').removeClass('incorrect');
        if ($(this).closest('p').find('input').val() == 'true') {
            $(this).closest('p').addClass('correct');
            $(this).closest('.input-field').find('.positive').fadeIn(2000);
        }
        else {
            $(this).closest('p').addClass('incorrect');
            $(this).closest('.input-field').find('.negative').fadeIn(2000);
        }
    });
}
/* Drag and Drop */
function drag_drop() {
    var thisElement;
    $('.drag-it').draggable({
        drag: function (event, ui) {
            thisElement = $(this);
        }
        , revert: true
    });
    $('.drop-it').droppable({
        drop: function (event, ui) {
            thisElement.closest('.dd-group').find('.positive').hide();
            thisElement.closest('.dd-group').find('.negative').hide();
            if (thisElement.data('result') == $(this).data('result')) {
                thisElement.draggable({
                    revert: false
                });
                $(this).addClass('correct');
                thisElement.closest('.dd-group').find('.positive').fadeIn(2000);
                if (thisElement.data('inner')) {
                    $(this).append(thisElement.html());
                    thisElement.remove();
                }
            }
            else {
                thisElement.closest('.dd-group').find('.negative').fadeIn(2000);
            }
        }
        , tolerance: 'pointer'
    });
}

/* Drag and Drop multiple inner */
function drag_drop_inner() {
    var thisElement;
    $('.drag-drop-inner .drag-it').draggable({
        drag: function (event, ui) {
            thisElement = $(this);
        }
        , revert: true
    });
    $('.drag-drop-inner .drop-it').droppable({
        drop: function (event, ui) {
            $(this).append(thisElement.html());
        }
        , tolerance: 'pointer'
    });
}

/* Drag and Drop */
function orden_list() {
 $("#sortable").sortable();
    $("#sortable").disableSelection();
    $('#eval_sortable').click(function(event){
        event.preventDefault();
        $('#sortable li').removeClass('retro_mal');
        $('#sortable li').removeClass('retro_bien');
        var count = 1;
        $('#sortable li').each(function(){
            if($(this).data('place') != count){
                $('#retro').html('<p class="incorrect">Verifica la secuencia.</p>');
                $(this).addClass('retro_mal');
                return false;
            }

            count++;
            console.log(count);
            if(count == 5){
                $('#retro').html('<p class="correct">Contestaste correctamente.</p>');
                 $(this).addClass('retro_bien');
            }
        });
    });
}
