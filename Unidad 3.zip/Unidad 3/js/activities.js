var course_platform = 'https://ada.bunam.unam.mx:8091/moodle/solidarida/';
var activities = [
    /* Botón Continuar */
    {'activity' : 'next', 'url': 'course/view.php?id=', 'moodle': '22', section: ''},
    /* Unidad 1 */
    {'activity' : 'u101', 'url': 'mod/forum/view.php?id=', 'moodle': '744', section: 'u1/conceptos_basicos_de_administracion/05'},
    /* Unidad 2 */
    {'activity' : 'u201', 'url': 'mod/quiz/view.php?id=', 'moodle': '748', section: 'u2/entorno_organizacional/03'},
    /* Unidad 3 */
    {'activity' : 'u301', 'url': 'mod/forum/view.php?id=', 'moodle': '754', section: 'u3/aspectos/02'},
    /* Unidad 4 */
    {'activity' : 'u401', 'url': 'mod/assign/view.php?id=', 'moodle': '761', section: 'u4/gestion/10'},
    /* Evaluacion Final */
    {'activity' : 'opinion', 'url': 'mod/questionnaire/view.php?id=', 'moodle': '766', section: 'evaluacion'}
];
