var angularRoutingApp = angular.module('angularRoutingApp', ['ngRoute']);

angularRoutingApp.config(function($routeProvider) {

    $routeProvider
        .when('/', {
            templateUrl : 'content/01.html',
            controller  : 'mainController'
        })
        .when('/:page*', {
            templateUrl : function(urlattr){
                return 'content/' + urlattr.page + '.html'
            },
            controller  : 'mainController'
        });
});

angularRoutingApp.controller('mainController', function($scope) {
    angular.element('body > div.container').addClass('bg-container');
    angular.element('.container header').show();
    angular.element('#unit-block').show();
    angular.element('footer').show();
    angular.element('.paginate').show();
    load_functions();
});
